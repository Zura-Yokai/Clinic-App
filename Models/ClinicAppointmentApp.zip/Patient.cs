﻿using SharpDevelopWebApi.Models;
public class Patient: Person
{
	public int userId {get; set;}
	public string email { get; set; }
}